This is an emacs color theme based on the tango palette colors.

For screenshots and installation instructions, please look at :

<http://blog.nozav.org/post/2010/07/12/Updated-tangotango-emacs-color-theme>

[![flattr](http://api.flattr.com/button/button-compact-static-100x17.png)](http://flattr.com/thing/51774/Tangotango-emacs-color-theme)
